
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <p>
          Test Text
        </p>
      </header>
      <footer className='Footer'> 
      <div className='Counter'>
      <p>Counter Start</p>
      </div>
      <div className='Set'>
      <p>set</p>
      </div>
      <div className='Mas'>
        <p>+</p>
      </div>
      </footer>
    </div>
  );
}

export default App;
