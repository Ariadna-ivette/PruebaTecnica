import React from "react";
import { Component }  from 'react';

class App extends Component {
    constructor () {
        algo();
        this.state = {
            clicks: 0,
            valor: ''
        };

        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleChange(e) {
        this.setState({valor: e.target.valor});
    }

    handleSubmit(e) {
        e.preventDefault();
        alert('Número enviado: ' + this.state.valor )
    }
};

IncrementarNumero = () => {
    this.setState({clicks: this.state.clicks + 1 });
};

render() {
    return (
        <div>
        <button onClick={this.IncrementarNumero}>+</button>
        <form onSubmit={this.handleSubmit}>
            <label>Counter Start:
                <input type="text" value={this.state.valor} onChange={this.handleChange}></input> 
            </label>
            <input type="submit" value="Set">Set</input>
        </form>
        </div>
    );
}

export default App;